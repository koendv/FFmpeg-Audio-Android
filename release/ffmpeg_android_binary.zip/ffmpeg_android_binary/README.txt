Binaries of ffmpeg for android, without text relocations. For inclusion with TarsosDSP on Android. Audio only. 
